<?php
/**
 * Plugin deactivation tasks.
 *
 * @package ConnectLibrary
 */

namespace ConnectLibrary;

defined( 'ABSPATH' ) || exit;

/**
 * Handles safe deactivation work.
 */
final class Deactivator {
	/**
	 * Deactivate without deleting ConnectLibrary data.
	 */
	public static function deactivate(): void {
		flush_rewrite_rules();
	}
}
