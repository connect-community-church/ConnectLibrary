<?php
/**
 * ISBN normalization and validation helpers.
 *
 * @package ConnectLibrary
 */

namespace ConnectLibrary\Catalog;

/**
 * Normalizes and validates ISBN-10 and ISBN-13 values.
 */
final class Isbn {
	/**
	 * Normalize scanner/manual input to canonical ISBN characters.
	 *
	 * @param mixed $value Raw ISBN value.
	 */
	public static function normalize( mixed $value ): string {
		return strtoupper( preg_replace( '/[^0-9X]/i', '', (string) $value ) ?? '' );
	}

	/**
	 * Determine whether a value is a valid ISBN-10 or ISBN-13.
	 *
	 * @param mixed $value Raw ISBN value.
	 */
	public static function is_valid( mixed $value ): bool {
		$isbn = self::normalize( $value );

		return self::is_valid_isbn10( $isbn ) || self::is_valid_isbn13( $isbn );
	}

	/**
	 * Return the ISBN type, or an empty string for invalid input.
	 *
	 * @param mixed $value Raw ISBN value.
	 */
	public static function type( mixed $value ): string {
		$isbn = self::normalize( $value );
		if ( self::is_valid_isbn10( $isbn ) ) {
			return 'isbn_10';
		}
		if ( self::is_valid_isbn13( $isbn ) ) {
			return 'isbn_13';
		}

		return '';
	}

	/**
	 * Validate an ISBN-10 checksum.
	 *
	 * @param string $isbn Normalized ISBN value.
	 */
	private static function is_valid_isbn10( string $isbn ): bool {
		if ( 1 !== preg_match( '/^[0-9]{9}[0-9X]$/', $isbn ) ) {
			return false;
		}

		$sum = 0;
		for ( $i = 0; $i < 10; $i++ ) {
			$digit = 'X' === $isbn[ $i ] ? 10 : (int) $isbn[ $i ];
			$sum  += ( 10 - $i ) * $digit;
		}

		return 0 === $sum % 11;
	}

	/**
	 * Validate an ISBN-13 checksum.
	 *
	 * @param string $isbn Normalized ISBN value.
	 */
	private static function is_valid_isbn13( string $isbn ): bool {
		if ( 1 !== preg_match( '/^[0-9]{13}$/', $isbn ) ) {
			return false;
		}

		$sum = 0;
		for ( $i = 0; $i < 12; $i++ ) {
			$sum += (int) $isbn[ $i ] * ( 0 === $i % 2 ? 1 : 3 );
		}

		$check = ( 10 - ( $sum % 10 ) ) % 10;

		return $check === (int) $isbn[12];
	}
}
