<?php
/**
 * Public availability resolver for catalog titles.
 *
 * @package ConnectLibrary
 */

namespace ConnectLibrary\Catalog;

use ConnectLibrary\Support\Statuses;

/**
 * Converts internal/manual title state into privacy-safe public availability.
 */
final class Availability {
	public const META_STATUS     = '_connectlibrary_public_availability';
	public const META_VISIBILITY = '_connectlibrary_public_visibility';

	/**
	 * Public labels keyed by availability status.
	 *
	 * @return array<string,string>
	 */
	public static function labels(): array {
		return array(
			Statuses::AVAILABILITY_AVAILABLE          => __( 'Available', 'connectlibrary' ),
			Statuses::AVAILABILITY_RESERVED           => __( 'Reserved', 'connectlibrary' ),
			Statuses::AVAILABILITY_CHECKED_OUT        => __( 'Checked Out', 'connectlibrary' ),
			Statuses::AVAILABILITY_WAITLIST_AVAILABLE => __( 'Waitlist Available', 'connectlibrary' ),
			Statuses::AVAILABILITY_UNAVAILABLE        => __( 'Unavailable', 'connectlibrary' ),
			Statuses::AVAILABILITY_HIDDEN             => __( 'Hidden', 'connectlibrary' ),
		);
	}

	/**
	 * Request behavior keyed by availability status.
	 *
	 * @return array<string,string>
	 */
	public static function request_actions(): array {
		return array(
			Statuses::AVAILABILITY_AVAILABLE          => 'reserve',
			Statuses::AVAILABILITY_RESERVED           => 'waitlist',
			Statuses::AVAILABILITY_CHECKED_OUT        => 'waitlist',
			Statuses::AVAILABILITY_WAITLIST_AVAILABLE => 'waitlist',
			Statuses::AVAILABILITY_UNAVAILABLE        => 'contact_librarian',
			Statuses::AVAILABILITY_HIDDEN             => 'none',
		);
	}

	/**
	 * Sort rank for public availability results. Lower ranks sort first.
	 *
	 * @return array<string,int>
	 */
	public static function sort_ranks(): array {
		return array(
			Statuses::AVAILABILITY_AVAILABLE          => 10,
			Statuses::AVAILABILITY_WAITLIST_AVAILABLE => 20,
			Statuses::AVAILABILITY_RESERVED           => 30,
			Statuses::AVAILABILITY_CHECKED_OUT        => 40,
			Statuses::AVAILABILITY_UNAVAILABLE        => 50,
			Statuses::AVAILABILITY_HIDDEN             => 999,
		);
	}

	/**
	 * Normalize a manual Phase 1 availability value.
	 *
	 * @param mixed $status Stored or requested status value.
	 */
	public static function normalize_status( mixed $status ): string {
		$status = sanitize_key( (string) $status );

		if ( in_array( $status, Statuses::availability_statuses(), true ) ) {
			return $status;
		}

		return Statuses::AVAILABILITY_UNAVAILABLE;
	}

	/**
	 * Normalize public visibility.
	 *
	 * @param mixed $visibility Stored or requested visibility value.
	 */
	public static function normalize_visibility( mixed $visibility ): string {
		$visibility = sanitize_key( (string) $visibility );

		if ( in_array( $visibility, Statuses::visibility_statuses(), true ) ) {
			return $visibility;
		}

		return Statuses::VISIBILITY_PUBLIC;
	}

	/**
	 * Build the safe public availability object for a title.
	 *
	 * @param int $post_id Book post ID.
	 * @return array{status:string,label:string,request_action:string}
	 */
	public static function for_book( int $post_id ): array {
		$raw_visibility = get_post_meta( $post_id, self::META_VISIBILITY, true );
		$raw_status     = get_post_meta( $post_id, self::META_STATUS, true );
		$visibility     = '' === $raw_visibility ? Statuses::VISIBILITY_PUBLIC : self::normalize_visibility( $raw_visibility );
		$status         = '' === $raw_status ? Statuses::AVAILABILITY_AVAILABLE : self::normalize_status( $raw_status );

		if ( Statuses::VISIBILITY_HIDDEN === $visibility ) {
			$status = Statuses::AVAILABILITY_HIDDEN;
		}

		return self::response_for_status( $status );
	}

	/**
	 * Build a safe public availability response for a known status.
	 *
	 * @param string $status Public status key.
	 * @return array{status:string,label:string,request_action:string}
	 */
	public static function response_for_status( string $status ): array {
		$status  = Statuses::AVAILABILITY_HIDDEN === $status ? $status : self::normalize_status( $status );
		$labels  = self::labels();
		$actions = self::request_actions();

		return array(
			'status'         => $status,
			'label'          => $labels[ $status ],
			'request_action' => $actions[ $status ],
		);
	}

	/**
	 * Return whether a title should be shown in public catalog contexts.
	 *
	 * @param int $post_id Book post ID.
	 */
	public static function is_public( int $post_id ): bool {
		return Statuses::VISIBILITY_HIDDEN !== self::normalize_visibility( get_post_meta( $post_id, self::META_VISIBILITY, true ) );
	}

	/**
	 * Sanitize an availability filter from a request.
	 *
	 * @param mixed $filter Raw filter value.
	 * @return string[]
	 */
	public static function sanitize_filter( mixed $filter ): array {
		$values = is_array( $filter ) ? $filter : explode( ',', (string) $filter );
		$valid  = array();

		foreach ( $values as $value ) {
			$value = sanitize_key( (string) $value );
			if ( in_array( $value, Statuses::availability_statuses(), true ) ) {
				$valid[] = $value;
			}
		}

		return array_values( array_unique( $valid ) );
	}

	/**
	 * Get a comparable sort rank for a public status.
	 *
	 * @param string $status Public status key.
	 */
	public static function sort_rank( string $status ): int {
		$ranks = self::sort_ranks();

		return $ranks[ $status ] ?? $ranks[ Statuses::AVAILABILITY_UNAVAILABLE ];
	}
}
