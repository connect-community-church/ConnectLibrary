<?php
/**
 * Database schema management for ConnectLibrary catalog tables.
 *
 * @package ConnectLibrary
 */

namespace ConnectLibrary\Database;

use RuntimeException;

/**
 * Creates and upgrades the non-destructive Phase 1 catalog schema.
 */
final class Schema {
	/**
	 * WordPress option storing the installed catalog schema version.
	 */
	public const OPTION_NAME = 'connectlibrary_schema_version';

	/**
	 * Current ConnectLibrary catalog schema version.
	 */
	public const VERSION = '1.0.0';

	/**
	 * Build table names using the active WordPress table prefix.
	 *
	 * @param string|null $prefix Optional table prefix. Defaults to $wpdb->prefix.
	 * @return array<string,string>
	 * @throws RuntimeException When no WordPress database prefix is available.
	 */
	public static function table_names( ?string $prefix = null ): array {
		if ( null === $prefix ) {
			global $wpdb;

			if ( ! isset( $wpdb ) || ! isset( $wpdb->prefix ) ) {
				throw new RuntimeException( 'ConnectLibrary schema requires a WordPress database prefix.' );
			}

			$prefix = $wpdb->prefix;
		}

		return array(
			'authors'        => $prefix . 'connectlibrary_authors',
			'book_authors'   => $prefix . 'connectlibrary_book_authors',
			'series'         => $prefix . 'connectlibrary_series',
			'book_series'    => $prefix . 'connectlibrary_book_series',
			'copies'         => $prefix . 'connectlibrary_copies',
			'book_metadata'  => $prefix . 'connectlibrary_book_metadata',
			'import_sources' => $prefix . 'connectlibrary_import_sources',
		);
	}

	/**
	 * Create or upgrade catalog tables and save the schema version option.
	 *
	 * @throws RuntimeException When the WordPress database object is unavailable.
	 */
	public static function migrate(): void {
		global $wpdb;

		if ( ! isset( $wpdb ) || ! method_exists( $wpdb, 'get_charset_collate' ) ) {
			throw new RuntimeException( 'ConnectLibrary schema migration requires the WordPress database object.' );
		}

		if ( ! function_exists( 'dbDelta' ) ) {
			require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		}

		foreach ( self::sql_definitions( self::table_names(), $wpdb->get_charset_collate() ) as $sql ) {
			dbDelta( $sql );
		}

		update_option( self::OPTION_NAME, self::VERSION, false );
	}

	/**
	 * SQL definitions for the Phase 1 catalog schema.
	 *
	 * Tables are intentionally catalog-only. They do not create borrower,
	 * reservation, loan, audit-log, or Offline/PWA sync data structures.
	 *
	 * @param array<string,string> $tables Table names from table_names().
	 * @param string               $charset_collate Database charset/collation clause.
	 * @return array<string,string>
	 */
	public static function sql_definitions( array $tables, string $charset_collate ): array {
		return array(
			'authors'        => "CREATE TABLE {$tables['authors']} (
	id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
	display_name varchar(255) NOT NULL,
	sort_name varchar(255) DEFAULT NULL,
	slug varchar(200) NOT NULL,
	bio longtext DEFAULT NULL,
	external_ids longtext DEFAULT NULL,
	created_at datetime NOT NULL,
	updated_at datetime NOT NULL,
	PRIMARY KEY  (id),
	UNIQUE KEY slug (slug),
	KEY sort_name (sort_name(191)),
	KEY display_name (display_name(191))
) {$charset_collate};",
			'book_authors'   => "CREATE TABLE {$tables['book_authors']} (
	book_post_id bigint(20) unsigned NOT NULL,
	author_id bigint(20) unsigned NOT NULL,
	role varchar(32) NOT NULL DEFAULT 'author',
	position int(10) unsigned NOT NULL DEFAULT 0,
	created_at datetime NOT NULL,
	PRIMARY KEY  (book_post_id,author_id,role),
	KEY author_id (author_id),
	KEY book_position (book_post_id,position)
) {$charset_collate};",
			'series'         => "CREATE TABLE {$tables['series']} (
	id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
	name varchar(255) NOT NULL,
	sort_name varchar(255) DEFAULT NULL,
	slug varchar(200) NOT NULL,
	description longtext DEFAULT NULL,
	external_ids longtext DEFAULT NULL,
	created_at datetime NOT NULL,
	updated_at datetime NOT NULL,
	PRIMARY KEY  (id),
	UNIQUE KEY slug (slug),
	KEY sort_name (sort_name(191)),
	KEY name (name(191))
) {$charset_collate};",
			'book_series'    => "CREATE TABLE {$tables['book_series']} (
	book_post_id bigint(20) unsigned NOT NULL,
	series_id bigint(20) unsigned NOT NULL,
	series_position varchar(64) DEFAULT NULL,
	position_sort decimal(10,3) DEFAULT NULL,
	created_at datetime NOT NULL,
	PRIMARY KEY  (book_post_id,series_id),
	KEY series_id (series_id),
	KEY book_post_id (book_post_id),
	KEY series_position_sort (series_id,position_sort)
) {$charset_collate};",
			'copies'         => "CREATE TABLE {$tables['copies']} (
	id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
	book_post_id bigint(20) unsigned NOT NULL,
	copy_number int(10) unsigned NOT NULL DEFAULT 1,
	barcode varchar(100) DEFAULT NULL,
	isbn_10 varchar(20) DEFAULT NULL,
	isbn_13 varchar(20) DEFAULT NULL,
	condition_status varchar(20) NOT NULL DEFAULT 'good',
	item_status varchar(20) NOT NULL DEFAULT 'active',
	visibility varchar(20) NOT NULL DEFAULT 'public',
	room varchar(100) DEFAULT NULL,
	shelf varchar(100) DEFAULT NULL,
	section varchar(100) DEFAULT NULL,
	private_notes longtext DEFAULT NULL,
	created_at datetime NOT NULL,
	updated_at datetime NOT NULL,
	PRIMARY KEY  (id),
	UNIQUE KEY barcode (barcode),
	KEY book_post_id (book_post_id),
	KEY isbn_13 (isbn_13),
	KEY isbn_10 (isbn_10),
	KEY item_status (item_status),
	KEY location (room,shelf,section)
) {$charset_collate};",
			'book_metadata'  => "CREATE TABLE {$tables['book_metadata']} (
	book_post_id bigint(20) unsigned NOT NULL,
	subtitle varchar(255) DEFAULT NULL,
	isbn_10 varchar(20) DEFAULT NULL,
	isbn_13 varchar(20) DEFAULT NULL,
	publisher varchar(255) DEFAULT NULL,
	published_date varchar(32) DEFAULT NULL,
	language varchar(32) DEFAULT NULL,
	page_count int(10) unsigned DEFAULT NULL,
	age_level varchar(100) DEFAULT NULL,
	reading_level varchar(100) DEFAULT NULL,
	content_notes longtext DEFAULT NULL,
	church_notes longtext DEFAULT NULL,
	recommended tinyint(1) NOT NULL DEFAULT 0,
	rating decimal(3,2) DEFAULT NULL,
	cover_attachment_id bigint(20) unsigned DEFAULT NULL,
	metadata_source varchar(32) NOT NULL DEFAULT 'manual',
	raw_provider_payload longtext DEFAULT NULL,
	created_at datetime NOT NULL,
	updated_at datetime NOT NULL,
	PRIMARY KEY  (book_post_id),
	KEY isbn_13 (isbn_13),
	KEY isbn_10 (isbn_10),
	KEY publisher (publisher(191)),
	KEY language (language),
	KEY age_level (age_level),
	KEY recommended (recommended)
) {$charset_collate};",
			'import_sources' => "CREATE TABLE {$tables['import_sources']} (
	id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
	book_post_id bigint(20) unsigned DEFAULT NULL,
	provider varchar(50) NOT NULL,
	provider_record_id varchar(191) DEFAULT NULL,
	isbn_10 varchar(20) DEFAULT NULL,
	isbn_13 varchar(20) DEFAULT NULL,
	status varchar(32) NOT NULL DEFAULT 'manual',
	raw_payload longtext DEFAULT NULL,
	created_at datetime NOT NULL,
	PRIMARY KEY  (id),
	KEY book_post_id (book_post_id),
	KEY provider_record (provider,provider_record_id),
	KEY isbn_13 (isbn_13),
	KEY isbn_10 (isbn_10),
	KEY status (status)
) {$charset_collate};",
		);
	}
}
