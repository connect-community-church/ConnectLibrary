<?php
/**
 * Plugin activation tasks.
 *
 * @package ConnectLibrary
 */

namespace ConnectLibrary;

use ConnectLibrary\Catalog\CatalogServiceProvider;
use ConnectLibrary\Database\Schema;
use ConnectLibrary\Settings\Settings;

defined( 'ABSPATH' ) || exit;

/**
 * Handles safe, non-destructive activation work.
 */
final class Activator {
	/**
	 * Store the installed plugin version, initialize settings defaults, and refresh catalog rewrites.
	 *
	 * Activation intentionally does not create catalog records, borrower data,
	 * pages, emails, external API calls, or destructive migrations.
	 */
	public static function activate(): void {
		Schema::migrate();
		update_option( 'connectlibrary_version', CONNECTLIBRARY_VERSION, false );
		Settings::initialize_defaults();
		CatalogServiceProvider::register_catalog_objects();
		flush_rewrite_rules();
	}
}
