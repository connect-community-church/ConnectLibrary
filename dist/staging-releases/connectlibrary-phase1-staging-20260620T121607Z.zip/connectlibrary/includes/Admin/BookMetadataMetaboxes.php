<?php
/**
 * Admin metaboxes for Book metadata.
 *
 * @package ConnectLibrary
 */

namespace ConnectLibrary\Admin;

// phpcs:disable Squiz.Commenting.FunctionComment.MissingParamTag,Squiz.Commenting.VariableComment.Missing

use ConnectLibrary\Catalog\BookMetadata;
use ConnectLibrary\Catalog\BookMetadataRepository;
use ConnectLibrary\Catalog\BookPostType;
use ConnectLibrary\Catalog\BookRelationshipsRepository;
use ConnectLibrary\Catalog\CoverImporter;
use ConnectLibrary\Catalog\Isbn;
use ConnectLibrary\Catalog\IsbnMetadata;
use ConnectLibrary\Catalog\IsbnMetadataLookupService;
use ConnectLibrary\Support\Statuses;
use WP_Post;

/**
 * Registers librarian-friendly metadata fields on the Book edit screen.
 */
final class BookMetadataMetaboxes {
	private const NONCE_ACTION = 'connectlibrary_save_book_metadata';
	private const NONCE_NAME   = 'connectlibrary_book_metadata_nonce';
	private const FIELD_NAME   = 'connectlibrary_book_metadata';
	private const LOOKUP_META  = '_connectlibrary_pending_isbn_lookup';

	private BookMetadataRepository $metadata;
	private BookRelationshipsRepository $relationships;

	/**
	 * Create the metabox coordinator.
	 */
	public function __construct() {
		$this->metadata      = new BookMetadataRepository();
		$this->relationships = new BookRelationshipsRepository();
	}

	/**
	 * Register admin hooks.
	 */
	public function register(): void {
		add_action( 'add_meta_boxes_' . BookPostType::POST_TYPE, array( $this, 'add_metaboxes' ) );
		add_action( 'save_post_' . BookPostType::POST_TYPE, array( $this, 'save' ), 10, 2 );
	}

	/**
	 * Add grouped metaboxes.
	 */
	public function add_metaboxes(): void {
		add_meta_box(
			'connectlibrary_book_catalog_details',
			__( 'Catalog details', 'connectlibrary' ),
			array( $this, 'render_catalog_details' ),
			BookPostType::POST_TYPE,
			'normal',
			'high'
		);
		add_meta_box(
			'connectlibrary_book_authors_series',
			__( 'Authors and series', 'connectlibrary' ),
			array( $this, 'render_authors_series' ),
			BookPostType::POST_TYPE,
			'normal',
			'default'
		);
		add_meta_box(
			'connectlibrary_book_location_status',
			__( 'Location and item status', 'connectlibrary' ),
			array( $this, 'render_location_status' ),
			BookPostType::POST_TYPE,
			'side',
			'default'
		);
		add_meta_box(
			'connectlibrary_book_public_notes',
			__( 'Public notes and visibility', 'connectlibrary' ),
			array( $this, 'render_public_notes' ),
			BookPostType::POST_TYPE,
			'normal',
			'default'
		);
		add_meta_box(
			'connectlibrary_book_private_notes',
			__( 'Librarian/internal notes', 'connectlibrary' ),
			array( $this, 'render_private_notes' ),
			BookPostType::POST_TYPE,
			'normal',
			'default'
		);
		add_meta_box(
			'connectlibrary_book_source_details',
			__( 'Metadata source/import details', 'connectlibrary' ),
			array( $this, 'render_source_details' ),
			BookPostType::POST_TYPE,
			'normal',
			'low'
		);
	}

	/**
	 * Save submitted Book metadata.
	 *
	 * @param int     $post_id Book post ID.
	 * @param WP_Post $post Post object.
	 */
	public function save( int $post_id, WP_Post $post ): void {
		if ( BookPostType::POST_TYPE !== $post->post_type ) {
			return;
		}
		if ( wp_is_post_autosave( $post_id ) || wp_is_post_revision( $post_id ) ) {
			return;
		}
		if ( ! isset( $_POST[ self::NONCE_NAME ] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST[ self::NONCE_NAME ] ) ), self::NONCE_ACTION ) ) {
			return;
		}
		if ( ! current_user_can( 'edit_post', $post_id ) ) {
			return;
		}

		$raw    = isset( $_POST[ self::FIELD_NAME ] ) && is_array( $_POST[ self::FIELD_NAME ] ) ? wp_unslash( $_POST[ self::FIELD_NAME ] ) : array();
		$fields = BookMetadata::sanitize( $raw );

		if ( isset( $_POST['connectlibrary_apply_isbn_lookup'] ) ) {
			$fields = $this->apply_lookup_selection( $post_id, $fields );
			delete_post_meta( $post_id, self::LOOKUP_META );
		}

		$this->metadata->save( $post_id, $fields );
		$this->relationships->save( $post_id, $fields );

		if ( isset( $_POST['connectlibrary_isbn_lookup'] ) ) {
			$this->lookup_isbn_metadata( $post_id, $fields );
		}
	}

	/**
	 * Render catalog detail fields.
	 */
	public function render_catalog_details( WP_Post $post ): void {
		$fields = $this->load_fields( $post->ID );
		wp_nonce_field( self::NONCE_ACTION, self::NONCE_NAME );
		$this->text_input( 'isbn_10', __( 'ISBN-10', 'connectlibrary' ), $fields['isbn_10'], __( 'Optional 10-digit ISBN. Hyphens are okay; they are cleaned when saved.', 'connectlibrary' ) );
		$this->text_input( 'isbn_13', __( 'ISBN-13', 'connectlibrary' ), $fields['isbn_13'], __( 'Optional 13-digit ISBN used by later import and catalog workflows.', 'connectlibrary' ) );
		$this->text_input( 'subtitle', __( 'Subtitle', 'connectlibrary' ), $fields['subtitle'], __( 'Shown with the book title in later catalog views.', 'connectlibrary' ) );
		$this->text_input( 'publisher', __( 'Publisher', 'connectlibrary' ), $fields['publisher'] );
		$this->text_input( 'published_date', __( 'Publication date/year', 'connectlibrary' ), $fields['published_date'], __( 'Use a year or full date if known.', 'connectlibrary' ) );
		$this->text_input( 'language', __( 'Language', 'connectlibrary' ), $fields['language'], __( 'Short label such as English or en.', 'connectlibrary' ) );
		$this->number_input( 'page_count', __( 'Page count', 'connectlibrary' ), (int) $fields['page_count'] );
		$this->text_input( 'age_level', __( 'Age/reading level note', 'connectlibrary' ), $fields['age_level'], __( 'Use the Age / Reading Levels taxonomy for structured browsing; this note is for imported or edition-specific wording.', 'connectlibrary' ) );
		$this->text_input( 'reading_level', __( 'Reading level detail', 'connectlibrary' ), $fields['reading_level'] );
		echo '<p class="description">' . esc_html__( 'Use the Book cover image box for the main cover and the Book Categories/Tags/Age taxonomies for browsing.', 'connectlibrary' ) . '</p>';
	}

	/**
	 * Render author and series selectors.
	 */
	public function render_authors_series( WP_Post $post ): void {
		$fields     = $this->load_fields( $post->ID );
		$author_ids = $this->relationships->get_author_ids( $post->ID );
		$series     = $this->relationships->get_series_selection( $post->ID );
		$authors    = $this->relationships->list_authors();
		$all_series = $this->relationships->list_series();
		?>
		<p><?php echo esc_html__( 'Choose existing authors from the custom author table, or add a basic new author name if needed.', 'connectlibrary' ); ?></p>
		<label for="connectlibrary_author_ids"><strong><?php echo esc_html__( 'Authors', 'connectlibrary' ); ?></strong></label>
		<select id="connectlibrary_author_ids" name="<?php echo esc_attr( self::FIELD_NAME ); ?>[author_ids][]" multiple="multiple" style="width:100%;min-height:8em;">
			<?php foreach ( $authors as $author ) : ?>
				<option value="<?php echo esc_attr( (string) $author['id'] ); ?>" <?php selected( in_array( absint( $author['id'] ), $author_ids, true ) ); ?>><?php echo esc_html( (string) $author['display_name'] ); ?></option>
			<?php endforeach; ?>
		</select>
		<?php if ( empty( $authors ) ) : ?>
			<p class="description"><?php echo esc_html__( 'No author records exist yet. Enter a new author below to create the first one.', 'connectlibrary' ); ?></p>
		<?php endif; ?>
		<?php $this->text_input( 'new_author_display_name', __( 'Add new author name', 'connectlibrary' ), $fields['new_author_display_name'], __( 'Creates a basic author record and links it to this book when saved.', 'connectlibrary' ) ); ?>
		<hr />
		<label for="connectlibrary_series_id"><strong><?php echo esc_html__( 'Primary series', 'connectlibrary' ); ?></strong></label>
		<select id="connectlibrary_series_id" name="<?php echo esc_attr( self::FIELD_NAME ); ?>[series_id]" style="width:100%;">
			<option value="0"><?php echo esc_html__( 'No series', 'connectlibrary' ); ?></option>
			<?php foreach ( $all_series as $series_row ) : ?>
				<option value="<?php echo esc_attr( (string) $series_row['id'] ); ?>" <?php selected( absint( $series_row['id'] ), $series['series_id'] ); ?>><?php echo esc_html( (string) $series_row['name'] ); ?></option>
			<?php endforeach; ?>
		</select>
		<?php if ( empty( $all_series ) ) : ?>
			<p class="description"><?php echo esc_html__( 'No series records exist yet. Enter a new series below if this book belongs to one.', 'connectlibrary' ); ?></p>
		<?php endif; ?>
		<?php
		$this->text_input( 'new_series_name', __( 'Add new series name', 'connectlibrary' ), $fields['new_series_name'], __( 'Creates a basic series record when saved.', 'connectlibrary' ) );
		$this->text_input( 'series_position', __( 'Series number/order', 'connectlibrary' ), $series['series_position'], __( 'Examples: 1, 2.5, Prequel, Book 4.', 'connectlibrary' ) );
	}

	/** Render location/status fields. */
	public function render_location_status( WP_Post $post ): void {
		$fields = $this->load_fields( $post->ID );
		$this->text_input( 'room', __( 'Room', 'connectlibrary' ), $fields['room'] );
		$this->text_input( 'shelf', __( 'Shelf', 'connectlibrary' ), $fields['shelf'] );
		$this->text_input( 'section', __( 'Section', 'connectlibrary' ), $fields['section'] );
		$this->select_input( 'condition_status', __( 'Condition', 'connectlibrary' ), $fields['condition_status'], Statuses::condition_labels() );
		$this->select_input( 'item_status', __( 'Item status', 'connectlibrary' ), $fields['item_status'], Statuses::item_labels() );
	}

	/** Render public notes and visibility fields. */
	public function render_public_notes( WP_Post $post ): void {
		$fields = $this->load_fields( $post->ID );
		$this->select_input( 'visibility', __( 'Public catalog visibility', 'connectlibrary' ), $fields['visibility'], BookMetadata::visibility_labels() );
		$this->checkbox_input( 'recommended', __( 'Librarian/pastoral recommended', 'connectlibrary' ), (bool) $fields['recommended'] );
		$this->textarea_input( 'church_notes', __( 'Public church note', 'connectlibrary' ), $fields['church_notes'], __( 'A short note that may be shown publicly later, such as suitability or pickup context.', 'connectlibrary' ) );
		$this->textarea_input( 'content_notes', __( 'Content/advisory notes', 'connectlibrary' ), $fields['content_notes'], __( 'Public rendering is decided by a later catalog card.', 'connectlibrary' ) );
	}

	/** Render private notes. */
	public function render_private_notes( WP_Post $post ): void {
		$fields = $this->load_fields( $post->ID );
		$this->textarea_input( 'private_notes', __( 'Internal librarian notes', 'connectlibrary' ), $fields['private_notes'], __( 'Private operational notes. These are not included in public-safe metadata payloads or REST meta registration.', 'connectlibrary' ) );
	}

	/** Render source details. */
	public function render_source_details( WP_Post $post ): void {
		$fields = $this->load_fields( $post->ID );
		$this->select_input( 'metadata_source', __( 'Metadata source', 'connectlibrary' ), $fields['metadata_source'], Statuses::metadata_source_labels() );
		$this->text_input( 'source_provider', __( 'Source provider', 'connectlibrary' ), $fields['source_provider'] );
		$this->text_input( 'source_record_id', __( 'Source record ID', 'connectlibrary' ), $fields['source_record_id'] );
		$this->text_input( 'source_record_link', __( 'Source record link', 'connectlibrary' ), $fields['source_record_link'] );
		$this->text_input( 'last_metadata_refresh', __( 'Last metadata refresh', 'connectlibrary' ), $fields['last_metadata_refresh'], __( 'Optional timestamp or date from a later import process.', 'connectlibrary' ) );
		$this->render_isbn_lookup_controls( $post, $fields );
	}

	/** Run an ISBN lookup and store normalized suggestions for explicit review/apply. */
	private function lookup_isbn_metadata( int $post_id, array $fields ): void {
		$lookup_isbn = isset( $_POST['connectlibrary_lookup_isbn'] ) ? Isbn::normalize( wp_unslash( $_POST['connectlibrary_lookup_isbn'] ) ) : '';
		if ( '' === $lookup_isbn ) {
			$lookup_isbn = '' !== $fields['isbn_13'] ? (string) $fields['isbn_13'] : (string) $fields['isbn_10'];
		}

		$result = ( new IsbnMetadataLookupService() )->lookup( $lookup_isbn );
		update_post_meta( $post_id, self::LOOKUP_META, $result );
	}

	/** Apply selected suggested fields only after the librarian explicitly requests it. */
	private function apply_lookup_selection( int $post_id, array $fields ): array {
		$result = get_post_meta( $post_id, self::LOOKUP_META, true );
		if ( ! is_array( $result ) || 'found' !== ( $result['status'] ?? '' ) ) {
			return $fields;
		}

		$selected = isset( $_POST['connectlibrary_apply_lookup_fields'] ) && is_array( $_POST['connectlibrary_apply_lookup_fields'] ) ? array_map( 'sanitize_key', wp_unslash( $_POST['connectlibrary_apply_lookup_fields'] ) ) : array();
		$allowed  = array(
			'title',
			'subtitle',
			'authors',
			'publisher',
			'published_date',
			'description',
			'page_count',
			'language',
			'categories',
			'source',
			'cover',
		);
		$selected = array_values( array_intersect( $selected, $allowed ) );
		$apply    = IsbnMetadata::apply_fields( is_array( $result['metadata'] ?? null ) ? $result['metadata'] : array() );

		if ( in_array( 'title', $selected, true ) && '' !== $apply['title'] ) {
			wp_update_post(
				array(
					'ID'         => $post_id,
					'post_title' => $apply['title'],
				)
			);
		}
		if ( in_array( 'subtitle', $selected, true ) ) {
			$fields['subtitle'] = $apply['subtitle'];
		}
		if ( in_array( 'authors', $selected, true ) ) {
			$fields['new_author_display_name'] = $apply['new_author_display_name'];
		}
		if ( in_array( 'publisher', $selected, true ) ) {
			$fields['publisher'] = $apply['publisher'];
		}
		if ( in_array( 'published_date', $selected, true ) ) {
			$fields['published_date'] = $apply['published_date'];
		}
		if ( in_array( 'description', $selected, true ) ) {
			$fields['content_notes'] = $apply['content_notes'];
		}
		if ( in_array( 'page_count', $selected, true ) ) {
			$fields['page_count'] = $apply['page_count'];
		}
		if ( in_array( 'language', $selected, true ) ) {
			$fields['language'] = $apply['language'];
		}
		if ( in_array( 'categories', $selected, true ) ) {
			$fields['age_level'] = $apply['age_level'];
		}
		if ( in_array( 'source', $selected, true ) ) {
			$fields['metadata_source']       = $apply['metadata_source'];
			$fields['source_provider']       = $apply['source_provider'];
			$fields['source_record_id']      = $apply['source_record_id'];
			$fields['source_record_link']    = $apply['source_record_link'];
			$fields['last_metadata_refresh'] = $apply['last_metadata_refresh'];
		}
		if ( in_array( 'cover', $selected, true ) && is_array( $result['metadata'] ?? null ) && ! empty( $result['metadata']['cover_url_candidates'] ) ) {
			$replace = isset( $_POST['connectlibrary_replace_cover'] );
			( new CoverImporter() )->import_for_book( $post_id, $result['metadata'], $replace );
		}

		return $fields;
	}

	/** Render lookup controls and pending provider suggestions. */
	private function render_isbn_lookup_controls( WP_Post $post, array $fields ): void {
		$result = get_post_meta( $post->ID, self::LOOKUP_META, true );
		$isbn   = '' !== $fields['isbn_13'] ? $fields['isbn_13'] : $fields['isbn_10'];
		?>
		<hr />
		<p><strong><?php echo esc_html__( 'ISBN metadata lookup', 'connectlibrary' ); ?></strong></p>
		<p>
			<label for="connectlibrary_lookup_isbn"><?php echo esc_html__( 'Lookup ISBN', 'connectlibrary' ); ?></label><br />
			<input type="text" id="connectlibrary_lookup_isbn" name="connectlibrary_lookup_isbn" value="<?php echo esc_attr( (string) $isbn ); ?>" class="regular-text" />
			<button type="submit" class="button" name="connectlibrary_isbn_lookup" value="1"><?php echo esc_html__( 'Lookup metadata', 'connectlibrary' ); ?></button>
		</p>
		<p class="description"><?php echo esc_html__( 'Google Books is checked first, with Open Library fallback. Results are suggestions only until you apply selected fields.', 'connectlibrary' ); ?></p>
		<?php
		if ( ! is_array( $result ) ) {
			return;
		}

		$type = 'found' === ( $result['status'] ?? '' ) ? 'notice-success' : 'notice-warning';
		echo '<div class="notice ' . esc_attr( $type ) . ' inline"><p>' . esc_html( (string) ( $result['message'] ?? '' ) ) . '</p>';
		foreach ( is_array( $result['errors'] ?? null ) ? $result['errors'] : array() as $error ) {
			echo '<p>' . esc_html( (string) $error ) . '</p>';
		}
		echo '</div>';
		if ( 'found' !== ( $result['status'] ?? '' ) || ! is_array( $result['metadata'] ?? null ) ) {
			return;
		}

		$this->render_lookup_suggestions( $result['metadata'], $post->ID );
	}

	/** Render normalized suggestions with explicit apply checkboxes. */
	private function render_lookup_suggestions( array $metadata, int $post_id = 0 ): void {
		$rows = array(
			'title'          => array( __( 'Title', 'connectlibrary' ), $metadata['title'] ?? '' ),
			'subtitle'       => array( __( 'Subtitle', 'connectlibrary' ), $metadata['subtitle'] ?? '' ),
			'authors'        => array( __( 'Authors', 'connectlibrary' ), implode( ', ', (array) ( $metadata['authors'] ?? array() ) ) ),
			'publisher'      => array( __( 'Publisher', 'connectlibrary' ), $metadata['publisher'] ?? '' ),
			'published_date' => array( __( 'Publication date/year', 'connectlibrary' ), $metadata['published_date'] ?? '' ),
			'description'    => array( __( 'Description', 'connectlibrary' ), $metadata['description'] ?? '' ),
			'page_count'     => array( __( 'Page count', 'connectlibrary' ), $metadata['page_count'] ?? '' ),
			'language'       => array( __( 'Language', 'connectlibrary' ), $metadata['language'] ?? '' ),
			'categories'     => array( __( 'Categories/subjects', 'connectlibrary' ), implode( ', ', (array) ( $metadata['categories'] ?? array() ) ) ),
			'source'         => array( __( 'Source attribution', 'connectlibrary' ), trim( (string) ( $metadata['source_provider'] ?? '' ) . ' ' . (string) ( $metadata['source_record_id'] ?? '' ) ) ),
		);
		?>
		<table class="widefat striped">
			<thead>
				<tr>
					<th scope="col"><?php echo esc_html__( 'Field', 'connectlibrary' ); ?></th>
					<th scope="col"><?php echo esc_html__( 'Suggested value', 'connectlibrary' ); ?></th>
				</tr>
			</thead>
			<tbody>
				<?php foreach ( $rows as $key => $row ) : ?>
					<?php if ( '' === (string) $row[1] ) : ?>
						<?php continue; ?>
					<?php endif; ?>
					<tr>
						<td><label><input type="checkbox" name="connectlibrary_apply_lookup_fields[]" value="<?php echo esc_attr( $key ); ?>" /> <?php echo esc_html( $row[0] ); ?></label></td>
						<td><?php echo esc_html( (string) $row[1] ); ?></td>
					</tr>
				<?php endforeach; ?>
				<?php if ( ! empty( $metadata['cover_url_candidates'] ) ) : ?>
					<tr>
						<td style="vertical-align:top;">
							<label><input type="checkbox" name="connectlibrary_apply_lookup_fields[]" value="cover" /> <?php echo esc_html__( 'Cover image', 'connectlibrary' ); ?></label>
							<?php if ( $post_id > 0 && get_post_thumbnail_id( $post_id ) ) : ?>
								<br /><label><input type="checkbox" name="connectlibrary_replace_cover" value="1" /> <?php echo esc_html__( 'Replace existing cover', 'connectlibrary' ); ?></label>
							<?php endif; ?>
						</td>
						<td>
							<?php
							/* translators: %d: number of available cover image candidates. */
							echo esc_html( sprintf( __( '%d cover image candidate(s) available', 'connectlibrary' ), count( (array) $metadata['cover_url_candidates'] ) ) );
							?>
						</td>
					</tr>
				<?php endif; ?>
			</tbody>
		</table>
		<p><button type="submit" class="button button-primary" name="connectlibrary_apply_isbn_lookup" value="1"><?php echo esc_html__( 'Apply selected lookup fields', 'connectlibrary' ); ?></button></p>
		<?php
	}

	/** Load metadata with relationship fields. */
	private function load_fields( int $post_id ): array {
		$fields                    = $this->metadata->get( $post_id );
		$fields['author_ids']      = $this->relationships->get_author_ids( $post_id );
		$series                    = $this->relationships->get_series_selection( $post_id );
		$fields['series_id']       = $series['series_id'];
		$fields['series_position'] = $series['series_position'];

		return $fields;
	}

	/** Render text input. */
	private function text_input( string $key, string $label, mixed $value, string $help = '' ): void {
		printf( '<p><label><strong>%1$s</strong><br /><input type="text" name="%2$s[%3$s]" value="%4$s" class="widefat" /></label>', esc_html( $label ), esc_attr( self::FIELD_NAME ), esc_attr( $key ), esc_attr( (string) $value ) );
		$this->help( $help );
		echo '</p>';
	}

	/** Render number input. */
	private function number_input( string $key, string $label, int $value ): void {
		printf( '<p><label><strong>%1$s</strong><br /><input type="number" min="0" name="%2$s[%3$s]" value="%4$d" class="small-text" /></label></p>', esc_html( $label ), esc_attr( self::FIELD_NAME ), esc_attr( $key ), $value );
	}

	/** Render textarea. */
	private function textarea_input( string $key, string $label, mixed $value, string $help = '' ): void {
		printf( '<p><label><strong>%1$s</strong><br /><textarea name="%2$s[%3$s]" rows="4" class="widefat">%4$s</textarea></label>', esc_html( $label ), esc_attr( self::FIELD_NAME ), esc_attr( $key ), esc_textarea( (string) $value ) );
		$this->help( $help );
		echo '</p>';
	}

	/**
	 * Render select input.
	 *
	 * Accepts either a flat array of values (display label auto-generated from value)
	 * or an associative array of value => translatable label pairs.
	 */
	private function select_input( string $key, string $label, mixed $value, array $choices ): void {
		printf( '<p><label><strong>%1$s</strong><br /><select name="%2$s[%3$s]" class="widefat">', esc_html( $label ), esc_attr( self::FIELD_NAME ), esc_attr( $key ) );
		foreach ( $choices as $choice_key => $choice_val ) {
			if ( is_int( $choice_key ) ) {
				$opt_value = (string) $choice_val;
				$opt_label = ucfirst( str_replace( '_', ' ', $opt_value ) );
			} else {
				$opt_value = (string) $choice_key;
				$opt_label = (string) $choice_val;
			}
			printf( '<option value="%1$s" %2$s>%3$s</option>', esc_attr( $opt_value ), selected( $value, $opt_value, false ), esc_html( $opt_label ) );
		}
		echo '</select></label></p>';
	}

	/** Render checkbox input. */
	private function checkbox_input( string $key, string $label, bool $checked ): void {
		printf( '<p><label><input type="checkbox" name="%1$s[%2$s]" value="1" %3$s /> %4$s</label></p>', esc_attr( self::FIELD_NAME ), esc_attr( $key ), checked( $checked, true, false ), esc_html( $label ) );
	}

	/** Render help text. */
	private function help( string $help ): void {
		if ( '' !== $help ) {
			echo '<br /><span class="description">' . esc_html( $help ) . '</span>';
		}
	}
}
