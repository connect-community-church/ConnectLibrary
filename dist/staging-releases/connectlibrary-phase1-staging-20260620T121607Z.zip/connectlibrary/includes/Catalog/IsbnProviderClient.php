<?php
/**
 * ISBN metadata provider HTTP client.
 *
 * @package ConnectLibrary
 */

namespace ConnectLibrary\Catalog;

/**
 * Fetches and maps Google Books / Open Library ISBN responses.
 */
final class IsbnProviderClient {
	private const TIMEOUT_SECONDS = 5;

	/**
	 * Query Google Books by ISBN.
	 *
	 * @param string $isbn Normalized ISBN value.
	 * @return array{ok:bool,metadata:array<string,mixed>,error:string,not_found:bool}
	 */
	public function google_books( string $isbn ): array {
		$url = add_query_arg(
			array( 'q' => 'isbn:' . $isbn ),
			'https://www.googleapis.com/books/v1/volumes'
		);

		$response = $this->request_json( esc_url_raw( $url ) );
		if ( ! $response['ok'] ) {
			return $response;
		}

		$metadata = IsbnMetadata::from_google_books( $response['json'] );
		if ( ! IsbnMetadata::is_useful( $metadata ) ) {
			return $this->empty_result();
		}

		return array(
			'ok'        => true,
			'metadata'  => $metadata,
			'error'     => '',
			'not_found' => false,
		);
	}

	/**
	 * Query Open Library by ISBN.
	 *
	 * @param string $isbn Normalized ISBN value.
	 * @return array{ok:bool,metadata:array<string,mixed>,error:string,not_found:bool}
	 */
	public function open_library( string $isbn ): array {
		$url      = 'https://openlibrary.org/isbn/' . rawurlencode( $isbn ) . '.json';
		$response = $this->request_json( esc_url_raw( $url ) );
		if ( ! $response['ok'] ) {
			return $response;
		}

		$metadata = IsbnMetadata::from_open_library( $response['json'], $isbn );
		if ( ! IsbnMetadata::is_useful( $metadata ) ) {
			return $this->empty_result();
		}

		return array(
			'ok'        => true,
			'metadata'  => $metadata,
			'error'     => '',
			'not_found' => false,
		);
	}

	/**
	 * Fetch and decode JSON with WordPress HTTP APIs.
	 *
	 * @param string $url Provider URL.
	 * @return array{ok:bool,json:array<string,mixed>,metadata:array<string,mixed>,error:string,not_found:bool}
	 */
	private function request_json( string $url ): array {
		$response = wp_remote_get(
			$url,
			array(
				'timeout'     => self::TIMEOUT_SECONDS,
				'redirection' => 2,
				'user-agent'  => 'ConnectLibrary/' . ( defined( 'CONNECTLIBRARY_VERSION' ) ? CONNECTLIBRARY_VERSION : 'dev' ),
			)
		);

		if ( is_wp_error( $response ) ) {
			return $this->error_result( $response->get_error_message() );
		}

		$code = (int) wp_remote_retrieve_response_code( $response );
		if ( 404 === $code ) {
			return $this->empty_result();
		}
		if ( $code < 200 || $code >= 300 ) {
			return $this->error_result( 'Provider returned HTTP ' . $code . '.' );
		}

		$body = (string) wp_remote_retrieve_body( $response );
		$json = json_decode( $body, true );
		if ( ! is_array( $json ) ) {
			return $this->error_result( 'Provider returned invalid JSON.' );
		}

		return array(
			'ok'        => true,
			'json'      => $json,
			'metadata'  => IsbnMetadata::defaults(),
			'error'     => '',
			'not_found' => false,
		);
	}

	/** Empty/no-match result. */
	private function empty_result(): array {
		return array(
			'ok'        => false,
			'metadata'  => IsbnMetadata::defaults(),
			'error'     => '',
			'not_found' => true,
		);
	}

	/**
	 * Provider error result.
	 *
	 * @param string $message Provider error message.
	 */
	private function error_result( string $message ): array {
		return array(
			'ok'        => false,
			'metadata'  => IsbnMetadata::defaults(),
			'error'     => sanitize_text_field( $message ),
			'not_found' => false,
		);
	}
}
