<?php
/**
 * Main plugin bootstrap.
 *
 * @package ConnectLibrary
 */

namespace ConnectLibrary;

use ConnectLibrary\Admin\BookMetadataMetaboxes;
use ConnectLibrary\Admin\SettingsPage;
use ConnectLibrary\Admin\SetupWizard;
use ConnectLibrary\Admin\Status;
use ConnectLibrary\Catalog\CatalogServiceProvider;

defined( 'ABSPATH' ) || exit;

/**
 * Coordinates ConnectLibrary hooks for the current request.
 */
final class Plugin {
	/**
	 * Singleton instance.
	 *
	 * @var self|null
	 */
	private static ?self $instance = null;

	/**
	 * Admin status screen.
	 *
	 * @var Status
	 */
	private Status $status_screen;

	/**
	 * Admin settings screen.
	 *
	 * @var SettingsPage
	 */
	private SettingsPage $settings_page;

	/**
	 * Book metadata admin metaboxes.
	 *
	 * @var BookMetadataMetaboxes
	 */
	private BookMetadataMetaboxes $book_metadata_metaboxes;

	/**
	 * First-run setup wizard.
	 *
	 * @var SetupWizard
	 */
	private SetupWizard $setup_wizard;

	/**
	 * Catalog service provider.
	 *
	 * @var CatalogServiceProvider
	 */
	private CatalogServiceProvider $catalog;

	/**
	 * Create the plugin coordinator.
	 */
	private function __construct() {
		$this->status_screen           = new Status();
		$this->settings_page           = new SettingsPage();
		$this->book_metadata_metaboxes = new BookMetadataMetaboxes();
		$this->setup_wizard            = new SetupWizard();
		$this->catalog                 = new CatalogServiceProvider();
	}

	/**
	 * Get the plugin coordinator instance.
	 */
	public static function instance(): self {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * Register WordPress hooks.
	 */
	public function register(): void {
		add_action( 'init', array( $this, 'load_textdomain' ) );
		$this->catalog->register();

		if ( is_admin() ) {
			$this->status_screen->register();
			$this->settings_page->register();
			$this->book_metadata_metaboxes->register();
			$this->setup_wizard->register();
		}
	}

	/**
	 * Load translations when language files are available.
	 */
	public function load_textdomain(): void {
		load_plugin_textdomain(
			CONNECTLIBRARY_TEXT_DOMAIN,
			false,
			dirname( plugin_basename( CONNECTLIBRARY_PLUGIN_FILE ) ) . '/languages'
		);
	}
}
